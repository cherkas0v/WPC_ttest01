			<div class="footer">
				<?php wp_nav_menu(array('theme_location'=>'fmenu', 'menu_class'=>'nav', 'container'=>'false')); ?>
				<p>&copy; Footer content <a href="http://psd-html-css.ru">Link footer</a></p>
			</div>
		</div>
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<?php 
				$location = get_field('map');
				if( !empty($location) ): 
				?>
				<div class="acf-map">
					<div class="marker" data-lat="<?php echo $location['lat']; ?>" data-lng="<?php echo $location['lng']; ?>"></div>
				</div>
			<?php endif; ?>
			
		<?php endwhile; ?>
		<?php else: ?>
		<?php endif; ?>	
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDCSN2s_cm5pCM2Pk8n7ohoIQrMvbyMcog"></script>
	</body>
</html>