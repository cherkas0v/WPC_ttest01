<?php
/*
Template Name: First Shablon
*/
?>

<?php get_header() ?>

<div class="content">
<?php get_sidebar() ?>

	<div class="main" >
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<h1> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h1>
			<?php the_post_thumbnail(array(320, 320)) ?>			
			<?php the_content() ?> 

				<?php 
				$location = get_field('google_map');
				if( !empty($location) ):
				?>
				<div class="acf-map">
				 <div class="marker" data-lat="<?php echo $location['lat']; ?>" data-lng="<?php echo $location['lng']; ?>"></div>
				</div>
				<?php endif; ?>

			<blockquote title="blockquote"> 
				<?= get_post_meta( get_the_ID(), 'quote', true ); ?> 
				<br> 
				<?php the_date('d F, Y, H:s',''," — ")?> 
				<?php the_tags("Теги: ")?> 
			</blockquote>
			
		<?php endwhile; ?>
		<?php else: ?>
		<?php endif; ?>	


	</div>
</div>

<?php get_footer() ?>
