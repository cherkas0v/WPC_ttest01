<?php 

function add_js() {
	//register scripts
	wp_register_script( 'bootstrap-carousel', get_template_directory_uri().'/js/bootstrap-carousel.js', array('jquery') );
	wp_register_script( 'bootstrap-transition', get_template_directory_uri().'/js/bootstrap-transition.js', array('jquery') );
	wp_register_script( 'jquery', get_template_directory_uri().'/js/jquery.js', array('jquery') ); 
	wp_register_script( 'js', get_template_directory_uri().'/js/js.js', array('jquery') );
	wp_register_script( 'map', get_template_directory_uri().'/js/map.js', array('jquery') );

	wp_enqueue_script( 'bootstrap-carousel');
	wp_enqueue_script( 'bootstrap-transition');
	wp_enqueue_script( 'jquery'); 
	wp_enqueue_script( 'js');
	wp_enqueue_script( 'map');
}

//call js function
add_action( 'wp_enqueue_scripts', 'add_js' );



