<?php get_header() ?>
<!--Контент-->
<div class="content">
		<?php get_sidebar() ?>
	<!--Основная часть-->
	<div class="main" >
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<!-- posts -->
			<!-- title -->
			<h1> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h1>
			<!-- thumbnail -->
			<?php the_post_thumbnail(array(240, 240)) ?>
			<!-- post content -->
			<?php the_content('Перейти к полной статье') ?>

				<!-- google map (optional) -->
				<?php 
				$location = get_field('google_map');
				if( !empty($location) ):
				?>
				<div class="acf-map">
				 <div class="marker" data-lat="<?php echo $location['lat']; ?>" data-lng="<?php echo $location['lng']; ?>"></div>
				</div>
				<?php endif; ?>
			<!-- quote -->
			<blockquote title="blockquote"> 
				<?= get_post_meta( get_the_ID(), 'quote', true ); ?> 
				<br> 
				<!-- date and tegs -->
 				<?php the_date('d F, Y, H:s',''," — ")?> 
				<?php the_tags("Теги: ")?>
			</blockquote>
		<?php endwhile; ?>
		<!-- post navigation -->
		<?php else: ?>
		<!-- no posts found -->
		<?php endif; ?>		
	</div>
</div>
<!--Подвал-->
<?php get_footer() ?>
