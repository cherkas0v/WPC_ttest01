<?php get_header() ?>

<div class="content">
<?php get_sidebar() ?>

	<div class="main" >
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<h1> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h1>
			<?php the_post_thumbnail(array(320, 320)) ?>			
			<?php the_content() ?> 
		<?php endwhile; ?>

		<?php else: ?>

		<?php endif; ?>		
	</div>
</div>

<?php get_footer() ?>