<?php 

// add js
get_template_part( 'assets' );

// add style
function add_style() {
	wp_register_style('style', get_stylesheet_uri() );
	wp_enqueue_style('style');
}
add_action( 'wp_enqueue_scripts', 'add_style' );

// миниатюры
add_theme_support( 'post-thumbnails' );

// header - menu
register_nav_menu( 'menu', 'header-menu' );
// footer menu
register_nav_menu( 'fmenu', 'footer-menu' );

// //Load TGM Plugins
// require get_template_directory() . '\tgm\tgmpa.php';

//disable default image setting
function sgr_filter_image_sizes( $sizes) {
	unset( $sizes['thumbnail']);
	unset( $sizes['medium']);
	unset( $sizes['large']);
	return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'sgr_filter_image_sizes');


//custom image setting
if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
}

if ( function_exists( 'add_image_size' ) ) {
	add_image_size ("my_image_big", 1900, 1000, false);
	add_image_size ("my_image_med", 1000, 600, false);
	add_image_size ("my_image_sml", 600, 400, false);
	add_image_size ("my_image_tmb", 200, 200, true);
}

add_filter( 'image_size_names_choose', 'my_custom_sizes' );
function my_custom_sizes( $sizes ) {
	return array_merge( $sizes, array(
		'my_image_big' => 'Большая',
		'my_image_med' => 'Средняя',
		'my_image_sml' => 'Маленькая',
		'my_image_tmb' => 'Иконка',
	) );
}

//google API
function my_acf_google_map_api( $api ){
 	$api['key'] = 'AIzaSyDCSN2s_cm5pCM2Pk8n7ohoIQrMvbyMcog';
	return $api;
}
add_filter('acf/fields/google_map/api', 'my_acf_google_map_api');

function my_theme_add_scripts() {
	wp_enqueue_script( 'google-map', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDCSN2s_cm5pCM2Pk8n7ohoIQrMvbyMcog', array(), '3', true );
	wp_enqueue_script( 'google-map-init', get_template_directory_uri() . '/library/js/google-maps.js', array('google-map', 'jquery'), '0.1', true );
}
add_action( 'wp_enqueue_scripts', 'my_theme_add_scripts' );

// add taxonomy & custom types
require get_template_directory() . '/customtax.php';
// require get_template_directory() . '/custom-types.php';


/**
* Сайдбар виджеты (для общего развития)
**/
$args = array(
	'name'          => 'Сайдбар виджеты',
	'id'            => 'sidebar-id',
	'description'   => 'Тут будут размещяются виджеты сайдбара (когда он будет :) ',
	'class'         => '',
	'before_widget' => '<li id="%1" class="widget %2">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
register_sidebar( $args );



// ОТПРАВКА ПИСЕМ
function my_project_updated_send_email( $post_id ) { 
	//verify post is not a revision
	$mail       = 'serg1978ch@gmail.com';
	$post_title = get_the_title( $post_id ); 
	$post_url   = get_permalink( $post_id ); 
	$subject    = 'A post has been updated'; 
	$message    = "A post has been updated on your website:\n\n";
	$message   .= "<a href='". $post_url. "'>" .$post_title. "</a>\n\n"; 
	//send email 
	wp_mail( $mail, $subject, $message ); 
} 
add_action( 'save_post', 'my_project_updated_send_email' ); 

