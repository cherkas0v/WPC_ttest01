
<div class="it">
	<h2> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h2>
	<div> <?php the_content(); ?> </div>
</div>
