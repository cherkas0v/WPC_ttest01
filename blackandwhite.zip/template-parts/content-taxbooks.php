
<div class="it">
	<h2> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h2> <br>
	<blockquote title="blockquote"> 
		<?php echo get_post_meta( get_the_ID(), 'book_author', true ); ?> 
	</blockquote>
	<?php the_post_thumbnail(array(150, 100)) ?>	
	<div> <?php the_content(); ?> </div> <br>
</div>
