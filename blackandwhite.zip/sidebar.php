<!-- ALL DISABLE -->

<!-- 	<ul class="nav">
		<li><a href="index.html">Home</a></li>
		<li><a href="about.html">About</a></li>
		<li><a href="work.html">Work</a></li>
		<li><a href="blog.html">Blog</a></li>
		<li><a href="contacts.html">Contacts</a></li>
	</ul> -->

<!-- 	<?php wp_nav_menu(array('theme_location'=>'menu', 'menu_class'=>'nav', 'container'=>'false')); ?> -->