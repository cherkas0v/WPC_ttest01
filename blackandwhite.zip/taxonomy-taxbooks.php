<?php get_header() ?>

<div class="content">
<?php get_sidebar() ?>

 	<div class="main" >

		<h1> <?php single_term_title() ?> </h1>
	 		<?php
			$args = array(
				'post_type' => 'books',
			);
			$query = new WP_Query( $args );
			while ( $query->have_posts() ) { $query->the_post();
				get_template_part( 'template-parts/content', 'taxbooks' );
			} wp_reset_postdata();
		?>

	</div>

</div>

<?php get_footer() ?>