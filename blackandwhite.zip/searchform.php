<form class="search" role="search" method="get" id="searchform" class="searchform" action="http://port4lio.zzz.com.ua/">
	<input type="text" value="" name="s" id="s">
	<input type="image" src="<?php bloginfo('template_url'); ?>/images/button-search.png">
</form>

