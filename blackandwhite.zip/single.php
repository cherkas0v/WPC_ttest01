<?php get_header() ?>

<div class="content">
<?php get_sidebar() ?>

	<div class="main" >

		<?php
		while ( have_posts() ) : the_post();?>

			<h1> <a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a></h1>

			<?php the_post_thumbnail(array(320, 320)) ?>			
			<?php the_content() ?> 

			<blockquote title="blockquote"> <?php the_date('d F, Y, H:s',''," -- ")?> <?php the_tags("Теги: ")?> </blockquote>
			<?php if ( comments_open() || get_comments_number() ) :
				comments_template();


			endif;

		endwhile;
		?>

		<!-- show similar posts -->
		<h2>Читайте также:</h2><br>
		<?php
		// take our ID number
		$categories = get_the_category($post->ID);
		// form the query to the database 
		if ($categories) {
			$category_ids = array();
			foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
			// selection conditions
			$args=array(
				'category__in' => $category_ids,
				'post__not_in' => array($post->ID),
				'showposts' => '3',
				// 'orderby' => 'rand',
				'ignore_sticky_posts' => '1',
				'no_found_rows' => true,
				'cache_results' => false
			);
			// send query
			$my_query = new wp_query($args);
			// query output
			if( $my_query->have_posts() ) {
				echo '<ul>'; // formating like table
				// query output cycle
				while ($my_query->have_posts()) {
					$my_query->the_post();
					?>
					<!-- output with decoration -->
					<h3>
						<a href="<?php the_permalink() ?>" style="text-decoration: none; color: #838383;"><?php the_title()?> </a>
						<!-- clickable thumbnails -->
						<a href="<?php the_permalink() ?>"> <?php the_post_thumbnail(array(50, 50)) ?> <br><br><br><br> </a>			
					</h3>
					<?php
				}
				echo '</ul>';
			}
			wp_reset_query(); // reset query
		}
		?>
		
		
	</div>
</div>

<?php get_footer() ?>